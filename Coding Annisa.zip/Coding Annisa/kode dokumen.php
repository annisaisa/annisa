<?php
	$my_file= 'example.txt';
	$handle= fopen($my_file, 'r');
	$data= fread($handle, filesize($my_file));
	if ($data<>''){
		echo $data;
	}else{
		echo "<span style=color:red>data file kosong<span>";
	}
?>