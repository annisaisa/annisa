<!DOCTYPE html>
<html>
<head>
	<title>Simple Upload dan Download File</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="container">
		<div id="content">
			<h2>Download</h2>
			<p>Silahkan download file yang sudah di upload di website ini. Untuk mendownload anda bisa mengklik judul file yang diinginkan.</p>
			<p>
			<table class="table" width="100%" cellpadding="3" cellspacing="0" border="1">
				<tr>
					<th width="30">id_file</th>
					<th width="80">tgl_Upload</th>
					<th> Nama_file </th>
					<th width="70">Tipe_file</th>
					<th width="70">Ukuran_file</th>
					<th width="70">file </th>
				</tr>
			</table>
			</p>
</body>
</html>
