<?php
	$my_file = 'exampele.txt';
	$handle = fopen ($my_file, 'w')or die('cannot open file: ' .$my_file);
?>