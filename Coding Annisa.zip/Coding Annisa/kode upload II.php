<?php
	include ('koneksi.php');
	$query		= "SELECT id_file FROM file ORDER BY id_file DESC LIMIT 0,1";
	$execute	= mysql_query($query);
	$cek 		= mysql_num_rows($execute);
	$get_data 	= mysql_fetch_array($execute);
	$file_name	= $_FILES['file'] ['name'];
	$file_ext	= $_FILES['file'] ['type'];
	$file_size	= $_FILES['file'] ['size'];
	$fule_tmp	= $_FILES['file'] ['tmp_name'];
	$nama		= $_POST['name'];
	$tgl		= date("Y-m-d");
	if ($file_size <1044070) {
		if ($cek<>0) {
			$id = $get_data['id_file']+1;
		}else{
			$id = 1;
		}
		$lokasi = 'files/'.basename($id. ".$file_name");
		move_uploaded_file($file_tmp, lokasi)
		$in = mysql_query("INSERT INTO file VALUES('$id_file','$tgl_upload','$nama_file','$tipe_file','$ukuran_file','$file')") or die(mysql_error());
		if ($in) {
			echo '<div class="ok">SUCCESS: FILE berhasil di upload!</div>';
		}else{
			echo '<div class="error">ERROR: gagal upload file!</div>';
		}else{
			echo '<div class="error">ERROR: besar ukuran file (file size) maksimal 1 mb!!</div>';
	}
?>