<!DOCTYPE html>
<html>
<head>
	<title>Simple Upload dan Downnload File</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="container">
		<div id="content">
			<h2>Upload</h2>
			<p>Upload file anda dengan melengkapi from di bawah ini. File yang bisa di upload hanya file dengan ekstensi <b>.doc, .docx, .xls, .xlsx, .ppt, .pptx, .pdf, .rar, .zip</b> dan besar file (file size) maksimum hanya 1 MB</p>
			<p>
			<form action="kode_upload.php" method="post" enctype="multipart/ form-data">
			<table width="100%" align="center" border="0" bgcolor="#eee" cellpadding="2" cellspacing="0">
				<tr>
					<td width="40%" align="right">
						<b>Nama File</b></td><td><b>:</b>
						</td>
					<td>
						<input type="text" name="nama" size="40" required />
					</td>
				</tr>
				<tr>
					<td width="40%" align="right">
						<b>Pilih File</b></td><td><b>:</b>
						</td>
						<input type="file" name="file" required />
					</td>
				</tr>
				<tr>
					<td width="40%" align="right">
						<b>Pilih File</b></td><td><b>:</b>
						</td>
						<input type="file" name="file" required />
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td><td>&nbsp;</td>
					<td><input type="submit" name="upload" value="upload" /></td>
				</tr>
			</table>
			</form>
			</p>
		</div>
	</div>
</body>
</html>