<?php
$host ="localhost";
$user ="root";
$password ="";
$db ="dbafni";
$kon =mysgli_connect($host,$user,$password,$db);
if (!$kon){
	die("koneksi gagal:" mysqli_connect_error());
}
?>